# -*- coding: iso-8859-1 -*-
"""
MetPX Copyright (C) 2004-2006  Environment Canada
MetPX comes with ABSOLUTELY NO WARRANTY; For details type see the file
named COPYING in the root of the source directory tree.
"""

"""        
#############################################################################################
# Name: bulletinManager.py
#
# Authors: Louis-Philippe Th�riault
#         
# Date: Octobre 2004 
#       
#
# Description: Gestionnaire de bulletins
#
#
# Revision History: 
#   2005-10-01  NSD         Adding collection capability.
#
#############################################################################################
"""
import math, re, string, os, bulletinPlain, traceback, sys, time
import PXPaths

from DirectRoutingParser import DirectRoutingParser
import bulletinAm
import bulletinWmo

PXPaths.normalPaths()

__version__ = '2.0'

class bulletinManagerException(Exception):
    pass

class bulletinManager:
    """Manipulates bulletins as entities.  Does not modify contents.
       Bulletin Managers take care of reading bulletins from and writing them
       to disk.

       pathTemp             path
           - Required, must be on the same file system as pathSource.

       pathSource           path
           - Directory from which bulletins are read (if necessary.)

       mapEnteteDelai       map

            - maps bulletin headers to valid reception times.

                   the elements are tuples, 
                       -- element[0] is number of max. minutes before the hour, 
                       -- element[1] is number of max. minutes after the hour.

                       -- Set the map to None to turn off header validity checking.

                    sample: mapEnteteDelai = { 'CA':(5,20),'WO':(20,40)}

       SMHeaderFormat       Bool

            - if true, Add a line "AAXX jjhh4\\n" to SM/SI bulletins.

       ficCollection        path
        
            - Collection configuration file.
                Set to None to deactivate message collection.

       pathFichierCircuit   path
             - The routing table.  (Header2circuit.conf)
             - set to None to disable. 

       maxCompteur          Int
             - Maximum number before rollover of unique numbers in file names.


    """

    def __init__(self,
            pathTemp,
            logger,
            pathSource=None,
            maxCompteur=99999, \
            lineSeparator='\n',
            extension=':',
            pathFichierCircuit=None,
            mapEnteteDelai=None,
            source=None):

        self.pathTemp = self.__normalizePath(pathTemp)
        self.logger = logger
        self.pathSource = self.__normalizePath(pathSource)
        self.maxCompteur = maxCompteur
        self.lineSeparator = lineSeparator
        self.extension = extension
        self.mapEnteteDelai = mapEnteteDelai
        self.source = source

        # FIXME: this should be read from a config file, haven't understood enough yet.
        self.compteur = 0

        #map du contenu de bulletins en format brut
        #associe a leur arborescence absolue
        self.mapBulletinsBruts = {}

        # Init du map des circuits
        self.drp = DirectRoutingParser(pathFichierCircuit, self.source.ingestor.allNames, logger)
        self.drp.parse()
        #self.drp.logInfos()

        # Collection regex
        self.regex = re.compile(r'SACN|SICN|SMCN')

    def effacerFichier(self,nomFichier):
        try:
            os.remove(nomFichier)
        except:
            self.logger.error("(BulletinManager.effacerFichier(): Erreur d'effacement d'un bulletin)")
            raise

    def writeBulletinToDisk(self,unRawBulletin,compteur=True,includeError=True):
        """writeBulletinToDisk(bulletin [,compteur,includeError])

           unRawBulletin        String

                     - unRawBulletin is a string, instantiated
                       as a bulletin before it is written to disk 
                     - modifications to the contents are done via a
                       unObjetBulletin.doSpecificProcessing() call
                       before writing.

           compteur             Bool

                     - If true, include counter in file name.

           includeError         Bool

                     - If true, and the bulletin is problematic, prepend
                       the bulletin data with a diagnostic message.

        """
        
        if self.compteur > self.maxCompteur:
            self.compteur = 0

        self.compteur += 1
        
        unBulletin = self.__generateBulletin(unRawBulletin)
        unBulletin.doSpecificProcessing()

        # V�rification du temps d'arriv�e
        self.verifyDelay(unBulletin)

        # G�n�ration du nom du fichier
        nomFichier = self.getFileName(unBulletin,compteur=compteur)
        nomFichier = nomFichier + ':' + time.strftime( "%Y%m%d%H%M%S", time.gmtime(time.time()) )

        tempNom = self.pathTemp + nomFichier
        try:
            unFichier = os.open( tempNom , os.O_CREAT | os.O_WRONLY )

        except (OSError,TypeError), e:
            # Le nom du fichier est invalide, g�n�ration d'un nouveau nom

            self.logger.warning("Manipulation du fichier impossible! (Ecriture avec un nom non standard)")
            self.logger.error("Exception: " + ''.join(traceback.format_exception(Exception,e,sys.exc_traceback)))

            nomFichier = self.getFileName(unBulletin,error=True,compteur=compteur)
            tempNom = self.pathTemp + nomFichier
            unFichier = os.open( tempNom, os.O_CREAT | os.O_WRONLY )
        
        os.write( unFichier , unBulletin.getBulletin(includeError=includeError) )
        os.close( unFichier )
        os.chmod(tempNom,0644)

        entete = ' '.join(unBulletin.getHeader().split()[:2])

        # MG use filename for Pattern File Matching from source ...  (As Proposed by DL )
        if self.source.patternMatching:
            if not self.source.fileMatchMask(nomFichier) :
                self.logger.warning("Bulletin file rejected because of RX mask: " + nomFichier)
                os.unlink(tempNom)
                return

            """
            transfo = self.source.getTransformation(nomFichier)
            if transfo:
                newNames = Transformations.transfo(tempNom)

                for name in newNames:
                    self.source.ingestor.ingest()
            """

        if self.drp.routingInfos.has_key(entete):
            clist = self.drp.getHeaderClients(entete)
        else:
            clist = []

        if self.source.clientsPatternMatching:
            clist = self.source.ingestor.getMatchingClientNamesFromMasks(nomFichier, clist)

        #fet.directIngest( nomFichier, clist, tempNom, self.logger )
        self.source.ingestor.ingest(tempNom, nomFichier, clist)

        os.unlink(tempNom)

    def _writeBulletinToDisk(self,unRawBulletin,compteur=True,includeError=True):
        
        if self.compteur > self.maxCompteur:
            self.compteur = 0

        self.compteur += 1

        unBulletin = self.__generateBulletin(unRawBulletin)
        unBulletin.doSpecificProcessing()

        # V�rification du temps d'arriv�e
        self.verifyDelay(unBulletin)

        # G�n�ration du nom du fichier
        nomFichier = self.getFileName(unBulletin,compteur=compteur)
        nomFichier = nomFichier + ':' + time.strftime( "%Y%m%d%H%M%S", time.gmtime(time.time()) )

        tempNom = self.pathTemp + nomFichier
        try:
            unFichier = os.open( tempNom , os.O_CREAT | os.O_WRONLY )

        except (OSError,TypeError), e:
            # Le nom du fichier est invalide, g�n�ration d'un nouveau nom

            self.logger.warning("Manipulation du fichier impossible! (Ecriture avec un nom non standard)")
            self.logger.error("Exception: " + ''.join(traceback.format_exception(Exception,e,sys.exc_traceback)))

            nomFichier = self.getFileName(unBulletin,error=True,compteur=compteur)
            tempNom = self.pathTemp + nomFichier
            unFichier = os.open( tempNom, os.O_CREAT | os.O_WRONLY )

        os.write( unFichier , unBulletin.getBulletin(includeError=includeError) )
        os.close( unFichier )
        os.chmod(tempNom,0644)

        entete = ' '.join(unBulletin.getHeader().split()[:2])

        # MG use filename for Pattern File Matching from source ...  (As Proposed by DL )
        if self.source.patternMatching:
            if not self.source.fileMatchMask(nomFichier) :
                self.logger.warning("Bulletin file rejected because of RX mask: " + nomFichier)
                os.unlink(tempNom)
                return

            """
            transfo = self.source.getTransformation(nomFichier)
            if transfo:
                newNames = Transformations.transfo(tempNom)

                for name in newNames:
                    self.source.ingestor.ingest()
            """

        if self.drp.routingInfos.has_key(entete):
            clist = self.drp.getHeaderClients(entete)
        else:
            clist = []

        if self.source.clientsPatternMatching:
            clist = self.source.ingestor.getMatchingClientNamesFromMasks(nomFichier, clist)

        #fet.directIngest( nomFichier, clist, tempNom, self.logger )
        self.source.ingestor.ingest(tempNom, nomFichier, clist)

        os.unlink(tempNom)

    def __generateBulletin(self,rawBulletin):
        """__generateBulletin(rawBulletin) -> objetBulletin

           Retourne un objetBulletin d'� partir d'un bulletin
           "brut".

        """
        return bulletinPlain.bulletinPlain(rawBulletin,self.logger,self.lineSeparator)

    def getListeNomsFichiersAbsolus(self):
        return self.mapBulletinsBruts.keys()

    def __normalizePath(self,path):
        """normalizePath(path) -> path

           Retourne un path avec un '/' � la fin
        """

        if path != None:
            if path != '' and path[-1] != '/':
                path = path + '/'

        return path

    def createWhatFn(self,bulletin,compteur=True ):
        """createWhatFn(bulletin[,compteur]) -> whatfn

           Return the first token of the filename. Build out of the
           bulletin header, the station (if defined) and a counter
           the WHATFN should looked like (if all the informations needed
           are available)

           SACN31_CWAO_121435_RRA_CYUL_045440 

           Missing info are going to be left empty
           possible outcome are :

           SACN31_CWAO_121435__CYUL_045440
           SACN31_CWAO_121435_CCA__045440


        """

        # header : 1- get header from bulletin
        #          2- must be alphanumeric
        #          3- consider an empty BBB to add an '_'

        header = bulletin.getHeader()
        if (header.replace(' ','')).isalnum() :
           parts  = header.split()
           header = header.replace(' ','_')
           if len(parts) < 4 : header = header + '_'
        else :
           header = None

        # station name :  1- bulletin header must be good
        #                 2- get station from bulletin
        #                 3- must be alphanumeric
        #                 4- station in WhatFn is conditional to some bulletin type
        #                    bulletinAm      always have the station name in the WhatFn (if found)
        #                    bulletinWmo     SRCN40 have the station name in the WhatFn (if found)
        #                    bulletin-file ? SRCN40 have the station name in the WhatFn (if found)
        #                    collector       Don't place station in the filename

        station = ''
        if header != None :
           if not (self.source.type == 'collector'):
              station = bulletin.getStation()
           if station == None       : station = ''
           if not station.isalnum() : station = ''
           if not isinstance(bulletin, bulletinAm.bulletinAm) :
              if not (bulletin.getHeader())[:6] in ["SRCN40","SXCN40","SRMT60"] : station = ''
           
        # adding a counter to the file name insure its uniqueness

        strCompteur = ''
        if compteur :
           strCompteur = string.zfill(self.compteur, len(str(self.maxCompteur)))

        # correct header if needed

        if header == None : header = 'UNPRINTABLE_HEADER'

        # whatfn

        whatfn = header + '_' + station + '_' + strCompteur

        return whatfn


    def getFileName(self,bulletin,error=False, compteur=True ):
        """getFileName(bulletin[,error, compteur]) -> fileName

           Retourne le nom du fichier pour le bulletin. Si error
           est � True, c'est que le bulletin a tent� d'�tre �crit
           et qu'il y a des caract�re "ill�gaux" dans le nom,
           un nom de fichier "safe" est retourn�. Si le bulletin semble �tre
           correct mais que le nom du fichier ne peut �tre g�n�r�,
           les champs sont mis � ERROR dans l'extension.

           Si compteur est � False, le compteur n'est pas ins�r�
           dans le nom de fichier.

           Utilisation:

                G�n�rer le nom du fichier pour le bulletin concern�.
        """

        # whatfn
        whatfn = self.createWhatFn(bulletin,compteur)

        if bulletin.getError() == None and not error:

        # Bulletin normal
            try:
                return  whatfn + self.getExtension(bulletin,error).replace(' ','_')

            except Exception, e:
                # Une erreur est d�tect�e (probablement dans l'extension) et le nom est g�n�r� avec des erreurs
                # Si le compteur n'a pas �t� calcul�, c'est que le bulletin �tait correct,
                # mais si on est ici dans le code, c'est qu'il y a eu une erreur.

                self.logger.warning(e)
                whatfn = self.createWhatFn(bulletin,compteur)
                return 'PROBLEM_BULLETIN_' + whatfn + self.getExtension(bulletin,error=True).replace(' ','_')

        elif bulletin.getError() != None and not error:
            self.logger.warning("Le bulletin est erronn� " + bulletin.getError()[0] )
            return 'PROBLEM_BULLETIN_' + whatfn + self.getExtension(bulletin,error=True).replace(' ','_')
        else:
            self.logger.warning("L'ent�te n'est pas imprimable" )
            return ('PROBLEM_BULLETIN ' + 'UNPRINTABLE HEADER ' + self.getExtension(bulletin,error)).replace(' ','_')

    def getExtension(self,bulletin,error=False):
        """getExtension(bulletin) -> extension

           Retourne l'extension � donner au bulletin. Si error est � True,
           les champs 'dynamiques' sont mis � 'PROBLEM'.

           -TT:         Type du bulletin (2 premieres lettres)
           -CCCC:       Origine du bulletin (2e champ dans l'ent�te
           -CIRCUIT:    Liste des circuits, s�par�s par des points,
                        pr�c�d�s de la priorit�.

           Exceptions possibles:
                bulletinManagerException:       Si l'extension ne peut �tre g�n�r�e
                                                correctement et qu'il n'y avait pas
                                                d'erreur � l'origine.

           Utilisation:

                G�n�rer la portion extension du nom du fichier.
        """
        newExtension = self.extension

        if not error and bulletin.getError() == None:
            newExtension = newExtension.replace('-TT',bulletin.getType())\
                                       .replace('-CCCC',bulletin.getOrigin())

            if self.drp != None:
            # Si les circuits sont activ�s
            # NB: L�ve une exception si l'ent�te est introuvable
                newExtension = newExtension.replace('-CIRCUIT',self.getCircuitList(bulletin))

            return newExtension
        else:
            # Une erreur est d�tect�e dans le bulletin
            newExtension = newExtension.replace('-TT','PROBLEM')\
                                       .replace('-CCCC','PROBLEM')\
                                       .replace('-CIRCUIT','PROBLEM')

            return newExtension

    def lireFicTexte(self,pathFic):
        """
           lireFicTexte(pathFic) -> liste des lignes

           pathFic:        String
                           - Chemin d'acc�s vers le fichier texte

           liste des lignes:       [str]
                                   - Liste des lignes du fichier texte

        Utilisation:

                Retourner les lignes d'un fichier, utile pour lire les petites
                databases dans un fichier ou les fichiers de config.
        """
        if os.access(pathFic,os.R_OK):
            f = open(pathFic,'r')
            lignes = f.readlines()
            f.close
            return lignes
        else:
            self.logger.error("Unable to access:" + pathFic )
            raise IOError

    def getCircuitList(self,bulletin):
        """circuitRename(bulletin) -> Circuits

           bulletin:    Objet bulletin

           Circuits:    String
                        -Circuits formatt�s correctement pour �tres ins�r�s dans l'extension

           Retourne la liste des circuits pour le bulletin pr�c�d�s de la priorit�, pour �tre ins�r�
           dans l'extension.

              Exceptions possibles:
                   bulletinManagerException:       Si l'ent�te ne peut �tre trouv�e dans le
                                                   fichier de circuits
        """
        if self.drp == None:
            raise bulletinManagerException("The Direct Routing Parser is not loaded")

        entete = ' '.join(bulletin.getHeader().split()[:2])

        if not self.drp.routingInfos.has_key(entete):
            bulletin.setError('Entete +' +entete+ ' non trouv�e dans fichier de circuits')
            raise bulletinManagerException('Entete non trouv�e dans fichier de circuits')

        return self.drp.getHeaderPriority(entete)

    def getPathSource(self):
        """getPathSource() -> Path_source

           Path_source:         String
                                -Path source que contient le manager
        """
        return self.pathSource

    def verifyDelay(self,unBulletin):
        """verifyDelay(unBulletin)

           V�rifie que le bulletin est bien dans les d�lais (si l'option
           de d�lais est activ�e). Flag le bulletin en erreur si le delai
           n'est pas respect�.

           Ne peut v�rifier le d�lai que si self.mapEnteteDelai n'est
           pas � None.

           Utilisation:

                Pouvoir v�rifier qu'un bulletin soit dans les d�lais
                acceptables.
        """
        if (self.mapEnteteDelai == None):
            return

        now = time.strftime("%d%H%M",time.localtime())

        try:
            bullTime = unBulletin.getHeader().split()[2]
            header = unBulletin.getHeader()

            minimum,maximum = None,None

            for k in self.mapEnteteDelai.keys():
            # Fetch de l'intervalle valide dans le map
                if k == header[:len(k)]:
                    (minimum,maximum) = self.mapEnteteDelai[k]
                    break

            if minimum == None:
            # Si le cas n'est pas d�fini, consid�r� comme correct
                return

        except Exception:
            unBulletin.setError('D�coupage d\'ent�te impossible')
            return

        # D�tection si wrap up et correction pour le calcul
        if abs(int(now[:2]) - int(bullTime[:2])) > 10:
            if now > bullTime:
            # Si le temps pr�sent est plus grand que le temps du bulletin
            # (donc si le bulletin est g�n�r� le mois suivant que pr�sentement),
            # On ajoute une journ�e au temps pr�sent pour faire le temps du bulletin
                bullTime = str(int(now[:2]) + 1) + bullTime[2:]
            else:
            # Contraire (...)
                now = str(int(bullTime[:2]) + 1) + now[2:]

        # Conversion en nombre de minutes
        nbMinNow = 60 * 24 * int(now[0:2]) + 60 * int(now[2:4]) + int(now[4:])
        nbMinBullTime = 60 * 24 * int(bullTime[0:2]) + 60 * int(bullTime[2:4]) + int(bullTime[4:])

        # Calcul de l'interval de validit�
        if not( -1 * abs(minimum) < nbMinNow - nbMinBullTime < maximum ):
            # La diff�rence se situe en dehors de l'intervale de validit�
            self.logger.warning("D�lai en dehors des limites permises bulletin: "+unBulletin.getHeader()+', heure pr�sente '+now)
            unBulletin.setError('Bulletin en dehors du delai permis')
